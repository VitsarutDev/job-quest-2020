import './App.css';
import { useEffect, useState } from 'react';
import { useForm } from "react-hook-form";

function App() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [result, setResult] = useState(0);

    const { register, handleSubmit } = useForm();
    const onSubmit = (data) => {
        setResult(0)
        setLoading(true)
        fetch("http://api.icndb.com/jokes/random?firstName="+data.firstname+"&lastName="+data.lastname)
            .then(res => res.json())
            .then(
                (result) => {
                    if (result.type === 'success') {
                        var temp = []
                        temp.push(result.value)
                        setData(temp)
                        setLoading(false)
                    }
                },
                (error) => {

                }
            )
    };

    
    useEffect(() => {
        fetch("http://api.icndb.com/jokes")
            .then(res => res.json())
            .then(
                (result) => {
                    if (result.type === 'success') {
                        setData(result.value);
                        setLoading(false);
                    }
                },
                (error) => {

                }
            )
    }, []);
    const onRandomResult = (e) => {
        const number = e.target.value
        setResult(number)
        setLoading(true);
        fetch("http://api.icndb.com/jokes/random/"+number)
            .then(res => res.json())
            .then(
                (result) => {
                    if (result.type === 'success') {
                        setData(result.value);
                        setLoading(false);
                    }
                },
                (error) => {

                }
            )
    }





    //random?firstName=John&lastName=Doe


    function Loading() {
        return (
            <div className="spinner">
                <div className="double-bounce1"></div>
                <div className="double-bounce2"></div>
            </div>
        );
    }

    function RenderInfo() {
        return (
            <>
            <h3 className="uk-text-center">Jokes List</h3>
                    <div uk-grid="true" className="uk-flex uk-flex-between">
                        <div>
                            <select className="uk-select" onChange={onRandomResult} value={result}>
                                <option value={0} disabled={true}>โปรดเลือกจำนวน</option>
                                <option value={10}>10</option>
                                <option value={20}>20</option>
                                <option value={30}>30</option>
                                <option value={40}>40</option>
                            </select>
                        </div>
                        

                        <div>
                            <form onSubmit={handleSubmit(onSubmit)}>
                                <div uk-grid="true" className="uk-grid-small">
                                    <div className="uk-width-1-3@m">
                                        <input 
                                            type="text" 
                                            className="uk-input" 
                                            placeholder="Firstname"
                                            name="firstname"
                                            ref={register({ required: true })}
                                        />
                                    </div>
                                    <div className="uk-width-1-3@m">
                                        <input 
                                            type="text" 
                                            className="uk-input" 
                                            placeholder="Lastname"
                                            name="lastname"
                                            ref={register({ required: true })}
                                        />
                                    </div>
                                    <div className="uk-width-1-3@m">
                                        <button className="uk-button uk-button-primary">ค้นหา</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <table className="uk-table uk-table-divider uk-table-small">
                        <thead>
                            <tr>
                                <th><b>ID</b></th>
                                <th><b>Name</b></th>
                            </tr>
                        </thead>
                        <tbody>
                            {data.map((item, index) => <tr key={index}>
                                <td>{item.id}</td>
                                <td>{item.joke}</td>
                            </tr>)}
                        </tbody>
                    </table>
            </>
        );
    }



    return (
        <section className="uk-section">
            <div className="uk-container">
                <div className="uk-card uk-card-default uk-card-body">
                    {loading===true ? <Loading/> : <RenderInfo />}
                </div>
            </div>
        </section>
    );
}

export default App;
